# Game of Life in JS

Fullstack Academy workshop.

