var gameOfLife = {

  width: 12,
  height: 12, // width and height dimensions of the board
  stepInterval: null, // should be used to hold reference to an interval that is "playing" the game

  createAndShowBoard: function () {

    // create <table> element
    var goltable = document.createElement("tbody");

    // build Table HTML
    var tablehtml = '';
    for (var h = 0; h < this.height; h++) {
      tablehtml += "<tr id='row+" + h + "'>";
      for (var w = 0; w < this.width; w++) {
        tablehtml += "<td data-status='dead' id='" + w + "-" + h + "'></td>";
      }
      tablehtml += "</tr>";
    }
    goltable.innerHTML = tablehtml;

    // add table to the #board element
    var board = document.getElementById('board');
    board.appendChild(goltable);

    // once html elements are added to the page, attach events to them
    this.setupBoardEvents();
  },

  forEachCell: function (iteratorFunc) {
    for (var i = 0; i < this.width; i++) {
      for (var j = 0; j < this.height; j++) {
        var cell = document.getElementById(j + "-" + i);
        iteratorFunc(cell, i, j);
      }
    }
  },

  setupBoardEvents: function () {
    document.getElementById("clear_btn").addEventListener("click", function () {
    /*var allCells = document.querySelectorAll("td");
    allCells.className = 'dead';
    console.log("clicked");
    console.log(allCells);*/
    // allCells.dataset.status = 'dead';
    for (var i = 0; i < this.width; i++) {
      for (var j = 0; j < this.height; j++) {
        var cell = document.getElementById(j + "-" + i);
        cell.className = 'dead';
        this.dataset.status = 'dead';
      }
      }

    })
    document.getElementById("step_btn").addEventListener("click", function () {
      gameOfLife.step();
    })

    var onCellClick = function (e) {

      // QUESTION TO ASK YOURSELF: What is "this" equal to here?

      // how to set the style of the cell when it's clicked
      if (this.dataset.status == 'dead') {
        this.className = 'alive';
        this.dataset.status = 'alive';
      } else {
        this.className = 'dead';
        this.dataset.status = 'dead';
      }

    };

    for (var i = 0; i < this.width; i++) {
      for (var j = 0; j < this.height; j++) {
        let cell = document.getElementById(j + "-" + i);
        cell.addEventListener('click', onCellClick);
      }
    }
  },

  classToggle: function(cell){
    if (cell.classList === "alive") cell.classList.toggle("dead");
    // if (cell.classList === "dead") cell.classList.toggle('alive')
  },

  changeArray: [],

  findNeighbors: function(x,y) {
    var abc=[[x+1,y],[x-1,y],[x,y+1],[x,y-1],[x-1,y-1],[x+1,y+1],[x+1,y-1]];
    var newMap = []
    abc.forEach(function(neighborArr){
    if (neighborArr[0] >= 0 && neighborArr[1] >= 0 && neighborArr[0] <= 11 && neighborArr[1] <= 11){
      newMap.push(neighborArr.join("-").split(","))
      }
    })
    return newMap;
  },

  checkBoard: function(cell, x, y) {
    let neighbors = gameOfLife.findNeighbors(x, y);
    let aliveCount = 0;

    if(cell.getAttribute("data-status")==="alive"){
       neighbors.forEach(function(neighbor){
        var cellID = neighbor.join("");
        if(document.getElementById(neighbor).getAttribute("data-status")==="alive") aliveCount++;
       });
        if(aliveCount<2 || aliveCount>3) gameOfLife.changeArray.push(cell)
      } else {
        neighbors.forEach(function(neighbor){
          var cellID = neighbor.join("");
          if (document.getElementById(neighbor).getAttribute("data-status")==="alive") aliveCount++;
        });

        if (aliveCount===3) gameOfLife.changeArray.push(cell);
       }
    },

  step: function () {
    gameOfLife.forEachCell(this.checkBoard);
    console.log(this.changeArray);
    this.changeArray.forEach(function(cell){
      if (cell.getAttribute("data-status") === "alive"){
        console.log("my cell is " + cell + " and i am " + cell.getAttribute("data-status"))
        cell.removeAttribute("data-status");
        cell.setAttribute("data-status","dead");
        gameOfLife.classToggle(cell);
      } else {
        console.log("my cell is " + cell + " and i am " + cell.getAttribute("data-status"))
        cell.removeAttribute("data-status");
        cell.setAttribute("data-status","alive");
        gameOfLife.classToggle(cell);
      }
    })
    this.changeArray = [];
  },

  enableAutoPlay: function () {
    // Start Auto-Play by running the 'step' function
    // automatically repeatedly every fixed time interval
  }

};

gameOfLife.createAndShowBoard();
